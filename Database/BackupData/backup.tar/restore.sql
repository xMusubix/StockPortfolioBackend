--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.2 (Debian 16.2-1.pgdg120+2)
-- Dumped by pg_dump version 16.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE stock_portfolio;
--
-- Name: stock_portfolio; Type: DATABASE; Schema: -; Owner: admin
--

CREATE DATABASE stock_portfolio WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE stock_portfolio OWNER TO admin;

\connect stock_portfolio

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: assets_table; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.assets_table (
    cost_value double precision,
    dividend_yield real,
    dividend_amount real,
    ex_date date,
    last_price real,
    last_price_change real,
    last_price_change_percentage real,
    mo_price_1 real,
    mo_price_3 real,
    mo_price_6 real,
    percent_year real,
    target real,
    total_share double precision,
    wk_price_1 real,
    year_high real,
    year_low real,
    year_price_1 real,
    ytd_price real,
    last_update_dividend timestamp(6) without time zone,
    last_update_history_price timestamp(6) without time zone,
    last_update_last_price timestamp(6) without time zone,
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    market_symbol character varying(20),
    note character varying(255),
    payout_ratio real,
    holding_value double precision
);


ALTER TABLE public.assets_table OWNER TO admin;

--
-- Name: exchange_rate_table; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.exchange_rate_table (
    date date NOT NULL,
    exchange_rate double precision NOT NULL,
    last_update date NOT NULL,
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL
);


ALTER TABLE public.exchange_rate_table OWNER TO admin;

--
-- Name: industry_table; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.industry_table (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    industry_name character varying(50) NOT NULL,
    sector_name character varying(50)
);


ALTER TABLE public.industry_table OWNER TO admin;

--
-- Name: sector_table; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.sector_table (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    sector_name character varying(50) NOT NULL
);


ALTER TABLE public.sector_table OWNER TO admin;

--
-- Name: transaction_cash_table; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.transaction_cash_table (
    date date NOT NULL,
    ex_rate double precision NOT NULL,
    thb double precision NOT NULL,
    usd real NOT NULL,
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    note character varying(255),
    type character varying(255) NOT NULL
);


ALTER TABLE public.transaction_cash_table OWNER TO admin;

--
-- Name: transaction_saving_table; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.transaction_saving_table (
    amount double precision NOT NULL,
    date date NOT NULL,
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    application character varying(255) NOT NULL,
    note character varying(255),
    type character varying(255) NOT NULL
);


ALTER TABLE public.transaction_saving_table OWNER TO admin;

--
-- Name: transaction_stock_table; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.transaction_stock_table (
    date date NOT NULL,
    fee real NOT NULL,
    price double precision NOT NULL,
    share double precision NOT NULL,
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    market_symbol character varying(20),
    note character varying(255),
    type character varying(255) NOT NULL
);


ALTER TABLE public.transaction_stock_table OWNER TO admin;

--
-- Name: watchlist_table; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.watchlist_table (
    line real,
    score real,
    last_update_jitta timestamp(6) without time zone,
    market character varying(10) NOT NULL,
    symbol character varying(10) NOT NULL,
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    market_symbol character varying(20) NOT NULL,
    state character varying(20),
    industry character varying(50),
    note character varying(255)
);


ALTER TABLE public.watchlist_table OWNER TO admin;

--
-- Data for Name: assets_table; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3422.dat

--
-- Data for Name: exchange_rate_table; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3429.dat

--
-- Data for Name: industry_table; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3423.dat

--
-- Data for Name: sector_table; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3424.dat

--
-- Data for Name: transaction_cash_table; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3425.dat

--
-- Data for Name: transaction_saving_table; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3426.dat

--
-- Data for Name: transaction_stock_table; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3427.dat

--
-- Data for Name: watchlist_table; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3428.dat

--
-- Name: assets_table assets_table_market_symbol_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.assets_table
    ADD CONSTRAINT assets_table_market_symbol_key UNIQUE (market_symbol);


--
-- Name: assets_table assets_table_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.assets_table
    ADD CONSTRAINT assets_table_pkey PRIMARY KEY (id);


--
-- Name: exchange_rate_table date; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.exchange_rate_table
    ADD CONSTRAINT date UNIQUE (date);


--
-- Name: exchange_rate_table exchange_rate_table_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.exchange_rate_table
    ADD CONSTRAINT exchange_rate_table_pkey PRIMARY KEY (id);


--
-- Name: industry_table industry_table_industry_name_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.industry_table
    ADD CONSTRAINT industry_table_industry_name_key UNIQUE (industry_name);


--
-- Name: industry_table industry_table_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.industry_table
    ADD CONSTRAINT industry_table_pkey PRIMARY KEY (id);


--
-- Name: sector_table sector_table_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.sector_table
    ADD CONSTRAINT sector_table_pkey PRIMARY KEY (id);


--
-- Name: sector_table sector_table_sector_name_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.sector_table
    ADD CONSTRAINT sector_table_sector_name_key UNIQUE (sector_name);


--
-- Name: transaction_cash_table transaction_cash_table_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.transaction_cash_table
    ADD CONSTRAINT transaction_cash_table_pkey PRIMARY KEY (id);


--
-- Name: transaction_saving_table transaction_saving_table_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.transaction_saving_table
    ADD CONSTRAINT transaction_saving_table_pkey PRIMARY KEY (id);


--
-- Name: transaction_stock_table transaction_stock_table_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.transaction_stock_table
    ADD CONSTRAINT transaction_stock_table_pkey PRIMARY KEY (id);


--
-- Name: watchlist_table watchlist_table_market_symbol_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.watchlist_table
    ADD CONSTRAINT watchlist_table_market_symbol_key UNIQUE (market_symbol);


--
-- Name: watchlist_table watchlist_table_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.watchlist_table
    ADD CONSTRAINT watchlist_table_pkey PRIMARY KEY (id);


--
-- Name: industry_table fk80dlsy9aly6hfsw49emhepvkn; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.industry_table
    ADD CONSTRAINT fk80dlsy9aly6hfsw49emhepvkn FOREIGN KEY (sector_name) REFERENCES public.sector_table(sector_name);


--
-- Name: transaction_stock_table fkmqa1megh3jitrvaosdkn363vw; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.transaction_stock_table
    ADD CONSTRAINT fkmqa1megh3jitrvaosdkn363vw FOREIGN KEY (market_symbol) REFERENCES public.watchlist_table(market_symbol);


--
-- Name: assets_table fkmthl0biem6agsumebwrf5bkli; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.assets_table
    ADD CONSTRAINT fkmthl0biem6agsumebwrf5bkli FOREIGN KEY (market_symbol) REFERENCES public.watchlist_table(market_symbol);


--
-- Name: watchlist_table fknxurkojt99t7yrvd9kvju9vc0; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.watchlist_table
    ADD CONSTRAINT fknxurkojt99t7yrvd9kvju9vc0 FOREIGN KEY (industry) REFERENCES public.industry_table(industry_name);


--
-- Name: DATABASE stock_portfolio; Type: ACL; Schema: -; Owner: admin
--

GRANT ALL ON DATABASE stock_portfolio TO stock_portfolio;


--
-- PostgreSQL database dump complete
--

